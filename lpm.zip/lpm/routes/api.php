<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuditController;
use App\Http\Controllers\TipeAuditController;
use App\Http\Controllers\StandarController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\FakultasController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\PerStandarController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');



// Endpoint untuk tipe audit
Route::get('/tipe-audits', [TipeAuditController::class, 'index']);
Route::post('/tipe-audits', [TipeAuditController::class, 'store']);
Route::get('/tipe-audits/{tipeAudit}', [TipeAuditController::class, 'show']);
Route::put('/tipe-audits/{tipeAudit}', [TipeAuditController::class, 'update']);
Route::delete('/tipe-audits/{tipeAudit}', [TipeAuditController::class, 'destroy']);

// Endpoint untuk standar
Route::get('/standars', [StandarController::class, 'index']);
Route::post('/standars', [StandarController::class, 'store']);
Route::get('/standars/{standar}', [StandarController::class, 'show']);
Route::put('/standars/{standar}', [StandarController::class, 'update']);
Route::delete('/standars/{standar}', [StandarController::class, 'destroy']);

// Endpoint untuk role
Route::get('/roles', [RoleController::class, 'index']);
Route::post('/roles', [RoleController::class, 'store']);
Route::get('/roles/{role}', [RoleController::class, 'show']);
Route::put('/roles/{role}', [RoleController::class, 'update']);
Route::delete('/roles/{role}', [RoleController::class, 'destroy']);

// Endpoint untuk fakultas
Route::get('/fakultas', [FakultasController::class, 'index']);
Route::post('/fakultas', [FakultasController::class, 'store']);
Route::get('/fakultas/{fakultas}', [FakultasController::class, 'show']);
Route::put('/fakultas/{fakultas}', [FakultasController::class, 'update']);
Route::delete('/fakultas/{fakultas}', [FakultasController::class, 'destroy']);

Route::get('/users', [UsersController::class, 'index']);
Route::post('/users', [UsersController::class, 'store']);
Route::get('/users/{user}', [UsersController::class, 'show']);
Route::put('/users/{user}', [UsersController::class, 'update']);
Route::delete('/users/{user}', [UsersController::class, 'destroy']);

Route::get('/per-standars', [PerStandarController::class, 'index']);
Route::post('/per-standars', [PerStandarController::class, 'store']);
Route::get('/per-standars/{perStandar}', [PerStandarController::class, 'show']);
Route::put('/per-standars/{perStandar}', [PerStandarController::class, 'update']);
Route::delete('/per-standars/{perStandar}', [PerStandarController::class, 'destroy']);

Route::get('/audits', [AuditController::class, 'index']);
Route::post('/audits', [AuditController::class, 'store']);
Route::get('/audits/{audit}', [AuditController::class, 'show']);
Route::put('/audits/{audit}', [AuditController::class, 'update']);
Route::delete('/audits/{audit}', [AuditController::class, 'destroy']);
