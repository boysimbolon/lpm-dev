<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    protected $table = 'tb_users';
    protected $fillable = [
        'username',
        'password',
        'id_fakultas',
        'id_roles',
    ];

    // Relasi dengan tb_fakultas
    public function fakultas()
    {
        return $this->belongsTo(Fakultas::class,'id_fakultas');
    }
    protected $hidden = [
        'password'
    ];
    // Relasi dengan tb_roles
    public function roles()
    {
        return $this->belongsTo(Roles::class,'id_roles');
    }
}
