<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PerStandar extends Model
{
    protected $table = 'tb_per_standars';
    protected $fillable = [
        'id_standars',
        'id_tipe_audits',
        'pernyataan_standar',
        'poin',
    ];

    // Relasi dengan tb_standars
    public function standar()
    {
        return $this->belongsTo(Standar::class,'id_standars');
    }

    // Relasi dengan tb_tipe_audits
    public function tipeAudit()
    {
        return $this->belongsTo(TipeAudit::class,'id_tipe_audits');
    }
}
