<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Audit extends Model
{
    protected $table = 'tb_audits';
    protected $fillable = [
        'id_per_standars',
        'id_users',
        'id_tipe_audits',
        'dok_pendukung',
    ];

    // Relasi dengan tb_per_standars
    public function perStandar()
    {
        return $this->belongsTo(PerStandar::class, 'id_per_standars');
    }

    // Relasi dengan tb_users
    public function users()
    {
        return $this->belongsTo(Users::class, 'id_users');
    }

    // Relasi dengan tb_tipe_audits
    public function tipeAudit()
    {
        return $this->belongsTo(TipeAudit::class, 'id_tipe_audits');
    }
}
