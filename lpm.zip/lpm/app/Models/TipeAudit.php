<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipeAudit extends Model
{
    protected $table = 'tb_tipe_audits';
    protected $fillable = [
        'tipe_audit',
    ];
}
