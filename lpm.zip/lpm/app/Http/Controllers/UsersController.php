<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    public function index()
    {
        $users = Users::with('Fakultas','Roles')->get();
        return response()->json($users);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'username' => 'required|string|max:50',
            'password' => 'required|string|max:250',
            'id_fakultas' => 'required|exists:tb_fakultas,id',
            'id_roles' => 'required|exists:tb_roles,id',
        ]);

        $user = Users::create($validatedData);
        return response()->json($user, 201);
    }

    public function show(Users $user)
    {
        $user->load(['Fakultas','Roles']);
        return response()->json($user);
    }

    public function update(Request $request, Users $user)
    {
        $validatedData = $request->validate([
            'username' => 'sometimes|required|string|max:50',
            'password' => 'sometimes|required|string|max:250',
            'id_fakultas' => 'sometimes|required|exists:tb_fakultas,id',
            'id_roles' => 'sometimes|required|exists:tb_roles,id',
        ]);

        $user->update($validatedData);
        return response()->json($user);
    }

    public function destroy(Users $user)
    {
        $user->delete();

        return response()->json(null, 204);
    }
}

