<?php

namespace App\Http\Controllers;

use App\Models\Roles;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index()
    {
        $roles = Roles::all();
        return response()->json($roles);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'jenis' => 'required|in:admin,audite,lpm'
        ]);
        $role = Roles::create($validatedData);
        return response()->json($role, 200);
    }

    public function show(Roles $role)
    {
        return response()->json($role);
    }

    public function update(Request $request, Roles $role)
    {
        $validatedData = $request->validate([
            'jenis' => 'sometimes|required|in:admin,audite,lpm',
        ]);

        $role->update($validatedData);

        return response()->json($role);
    }

    public function destroy(Roles $role)
    {
        $role->delete();

        return response()->json(null, 204);
    }
}

