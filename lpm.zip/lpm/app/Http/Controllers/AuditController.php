<?php
namespace App\Http\Controllers;

use App\Models\Audit;
use Illuminate\Http\Request;

class AuditController extends Controller
{
    public function index()
    {
        $audits = Audit::with('tb_standars','tb_users','tb_tipe_audits')->get();
        return response()->json($audits);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'id_per_standars' => 'required|exists:tb_standars,id',
            'id_users' => 'required|exists:tb_users,id',
            'id_tipe_audits' => 'required|exists:tb_tipe_audits,id',
            'dok_pendukung' => 'required|string|max:250',
        ]);

        $audit = Audit::create($validatedData);

        return response()->json($audit, 201);
    }

    public function show(Audit $audit)
    {
        $audit->load(['tb_standars','tb_users','tb_tipe_audits']);
        return response()->json($audit);
    }

    public function update(Request $request, Audit $audit)
    {
        $validatedData = $request->validate([
            'id_per_standars' => 'sometimes|required|exists:tb_standars,id',
            'id_users' => 'sometimes|required|exists:tb_users,id',
            'id_tipe_audits' => 'sometimes|required|exists:tb_tipe_audits,id',
            'dok_pendukung' => 'sometimes|required|string|max:250',
        ]);

        $audit->update($validatedData);

        return response()->json($audit);
    }

    public function destroy(Audit $audit)
    {
        $audit->delete();

        return response()->json(null, 204);
    }
}

