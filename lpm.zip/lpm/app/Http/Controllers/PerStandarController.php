<?php

namespace App\Http\Controllers;

use App\Models\PerStandar;
use Illuminate\Http\Request;

class PerStandarController extends Controller
{
    public function index()
    {
        $perStandars = PerStandar::with('tb_tipe_audits','tb_standars')->get();
        return response()->json($perStandars);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'id_standars' => 'required|exists:tb_standars,id',
            'id_tipe_audit' => 'required|exists:tb_tipe_audits,id',
            'pernyataan_standar' => 'required|string|max:400',
            'poin' => 'required|integer',
        ]);

        $perStandar = PerStandar::create($validatedData);

        return response()->json($perStandar, 201);
    }

    public function show(PerStandar $perStandar)
    {
        $perStandar->load(['tb_tipe_standars','tb_standars']);
        return response()->json($perStandar);
    }

    public function update(Request $request, PerStandar $perStandar)
    {
        $validatedData = $request->validate([
            'id_standars' => 'sometimes|required|exists:tb_standars,id',
            'id_tipe_audit' => 'sometimes|required|exists:tb_tipe_audits,id',
            'pernyataan_standar' => 'sometimes|required|string|max:400',
            'poin' => 'sometimes|required|integer',
        ]);

        $perStandar->update($validatedData);

        return response()->json($perStandar);
    }

    public function destroy(PerStandar $perStandar)
    {
        $perStandar->delete();

        return response()->json(null, 204);
    }
}
