<?php

namespace App\Http\Controllers;

use App\Models\Standar;
use Illuminate\Http\Request;

class StandarController extends Controller
{
    public function index()
    {
        $standars = Standar::all();
        return response()->json($standars);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'jenis_standar' => 'required|string|max:50',
        ]);
        $standar = Standar::create($validatedData);
        return response()->json($standar, 201);
    }

    public function show(Standar $standar)
    {
        return response()->json($standar);
    }

    public function update(Request $request, Standar $standar)
    {
        $validatedData = $request->validate([
            'jenis_standar' => 'sometimes|required|string|max:50',
        ]);

        $standar->update($validatedData);

        return response()->json($standar);
    }

    public function destroy(Standar $standar)
    {
        $standar->delete();

        return response()->json(null, 204);
    }
}

