<?php

namespace App\Http\Controllers;

use App\Models\TipeAudit;
use Illuminate\Http\Request;

class TipeAuditController extends Controller
{
    public function index()
    {
        $tipeAudits = TipeAudit::all();
        return response()->json($tipeAudits);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'tipe_audit' => 'required|string|max:255',
        ]);

        $tipeAudit = TipeAudit::create($validatedData);
        return response()->json($tipeAudit, 201);
    }

    public function show(TipeAudit $tipeAudit)
    {
        return response()->json($tipeAudit);
    }

    public function update(Request $request, TipeAudit $tipeAudit)
    {
        $validatedData = $request->validate([
            'tipe_audit' => 'sometimes|required|string|max:255',
        ]);

        $tipeAudit->update($validatedData);

        return response()->json($tipeAudit);
    }

    public function destroy(TipeAudit $tipeAudit)
    {
        $tipeAudit->delete();
        return response()->json(null, 204);
    }
}

