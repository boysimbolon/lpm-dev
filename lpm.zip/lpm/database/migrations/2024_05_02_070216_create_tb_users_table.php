<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tb_tipe_audits', function (Blueprint $table) {
            $table->id();
            $table->string('tipe_audit');
            $table->timestamps();
        });
        Schema::create('tb_standars', function (Blueprint $table) {
            $table->id();
            $table->string('jenis_standar',50);
            $table->timestamps();
        });
        Schema::create('tb_roles', function (Blueprint $table) {
            $table->id();
            $table->enum('jenis',['admin','audite','lpm']);
            $table->timestamps();
        });
        Schema::create('tb_fakultas', function (Blueprint $table) {
            $table->id();
            $table->string('fakultas');
            $table->string('prodi');
            $table->timestamps();
        });
        Schema::create('tb_users', function (Blueprint $table) {
            $table->id();
            $table->string('username',50);
            $table->string('password',250);
            $table->foreignId('id_fakultas');
            $table->foreign('id_fakultas')->references('id')->on('tb_fakultas')->onDelete('cascade')->onUpdate('cascade');
            $table->foreignId('id_roles');
            $table->foreign('id_roles')->references('id')->on('tb_roles')->onDelete('cascade')->onUpdate('cascade');
            $table->timestamps();
       });
        Schema::create('tb_per_standars', function (Blueprint $table) {
            $table->id();
            $table->foreignId('id_standars');
            $table->foreign('id_standars')->references('id')->on('tb_standars')->onDelete('cascade')->onUpdate('cascade');
            $table->foreignId('id_tipe_audits');
            $table->foreign('id_tipe_audits')->references('id')->on('tb_tipe_audits')->onDelete('cascade')->onUpdate('cascade');
            $table->text('pernyataan_standar');
            $table->integer('poin');
            $table->timestamps();
        });
        Schema::create('tb_audits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('id_per_standars');
            $table->foreignId('id_users');
            $table->foreignId('id_tipe_audits');
            $table->string('dok_pendukung');
            $table->timestamps();
            $table->foreign('id_per_standars')->references('id')->on('tb_standars')->onUpdate('cascade')->onDelete('cascade');
            $table->foreign('id_users')->references('id')->on('tb_users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('id_tipe_audits')->references('id')->on('tb_tipe_audits')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tb_users');
        Schema::dropIfExists('tb_standars');
        Schema::dropIfExists('tb_roles');
        Schema::dropIfExists('tb_fakultas');
        Schema::dropIfExists('tb_tipe_audits');
        Schema::dropIfExists('tb_per_standars');
        Schema::dropIfExists('tb_audits');
    }
};
